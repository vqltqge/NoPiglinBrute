package com.vqlt.nopiglinbrute;

import org.bukkit.entity.EntityType;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.CreatureSpawnEvent;

public class PiglinBruteSpawnListener implements Listener {

    private final NoPiglinBrute plugin;

    public PiglinBruteSpawnListener(NoPiglinBrute plugin) {
        this.plugin = plugin;
    }

    @EventHandler

    public void onPiglinBruteSpawn(CreatureSpawnEvent event) {
        if (plugin.areBrutesDisabled()) {
            if (event.getEntityType() == EntityType.PIGLIN_BRUTE) {
                if (event.getSpawnReason() != CreatureSpawnEvent.SpawnReason.COMMAND) {
                    event.setCancelled(true);
                }
            }
        }
    }
}
